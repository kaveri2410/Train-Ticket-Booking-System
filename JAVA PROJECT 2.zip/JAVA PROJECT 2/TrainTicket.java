import java.util.*;

// Passenger Class to Store Booking Information
class Passenger {
    String name;
    int age;
    String gender;
    int seatNo;

    public Passenger(String name, int age, String gender, int seatNo) {
        this.name = name;
        this.age = age;
        this.gender = gender;
        this.seatNo = seatNo;
    }

    public String toString() {
        return "Seat No: " + seatNo + " | Name: " + name + " | Age: " + age + " | Gender: " + gender;
    }
}

// Train Class Handles Booking, Cancellation, and Waitlist
class Train {
    int trainNumber;
    String trainName;
    int totalSeats;
    LinkedList<Passenger> bookedSeats = new LinkedList<>();
    Queue<Passenger> waitlist = new LinkedList<>();
    HashMap<String, Passenger> passengerMap = new HashMap<>();

    public Train(int number, String name, int seats) {
        this.trainNumber = number;
        this.trainName = name;
        this.totalSeats = seats;
    }

    // Book a Ticket
    void bookTicket(String name, int age, String gender) {
        if (passengerMap.containsKey(name)) {
            System.out.println(name + " already has a booking.");
            return;
        }

        if (bookedSeats.size() < totalSeats) {
            Passenger p = new Passenger(name, age, gender, bookedSeats.size() + 1);
            bookedSeats.add(p);
            passengerMap.put(name, p);
            System.out.println("Ticket Booked!\n" + p);
        } else {
            Passenger p = new Passenger(name, age, gender, -1);
            waitlist.add(p);
            System.out.println("Train Full! " + name + " added to Waitlist.");
        }
    }

    // Cancel a Ticket
    void cancelTicket(String name) {
        if (!passengerMap.containsKey(name)) {
            System.out.println("Passenger Not Found!");
            return;
        }

        Passenger removedPassenger = passengerMap.remove(name);
        bookedSeats.remove(removedPassenger);
        System.out.println(name + " canceled their ticket.");

        if (!waitlist.isEmpty()) {
            Passenger moved = waitlist.poll();
            moved.seatNo = bookedSeats.size() + 1;
            bookedSeats.add(moved);
            passengerMap.put(moved.name, moved);
            System.out.println(oved.name + " moved from Waitlist to Seat No: " + moved.seatNo);
        }
    }

    // Display Current Bookings
    void displayBookings() {
        System.out.println("\n Booked Passengers:");
        if (bookedSeats.isEmpty()) System.out.println("No bookings yet.");
        else bookedSeats.forEach(System.out::println);

        System.out.println("\n Waitlisted Passengers:");
        if (waitlist.isEmpty()) System.out.println("No waitlisted passengers.");
        else waitlist.forEach(p -> System.out.println("Name: " + p.name + " | Age: " + p.age + " | Gender: " + p.gender));
    }
}

// Main Class - Train Booking System
public class TrainTicketBooking {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Train train = new Train(101, "Express Train", 5);

        while (true) {
            showMenu();
            int choice = getValidChoice(sc);
            processChoice(choice, sc, train);
        }
    }
🎟
    static void showMenu() {
        System.out.println("\n️ TRAIN TICKET BOOKING SYSTEM ️");
        System.out.println("1.Book Ticket  2.Cancel Ticket  3.Show Bookings  4. Exit");
        System.out.print(" Choose an option: ");
    }

    static int getValidChoice(Scanner sc) {
        while (!sc.hasNextInt()) {
            System.out.println("Invalid input! Enter a number.");
            sc.next();
        }
        return sc.nextInt();
    }

    static void processChoice(int choice, Scanner sc, Train train) {
        sc.nextLine();
        switch (choice) {
            case 1 -> {
                System.out.print(" Enter Name: ");
                String name = sc.nextLine();
                System.out.print(" Enter Age: ");
                int age = sc.nextInt();
                sc.nextLine();
                System.out.print(" Enter Gender (M/F): ");
                String gender = sc.nextLine();
                train.bookTicket(name, age, gender);
            }
            case 2 -> {
                System.out.print("Enter Name to Cancel: ");
                String name = sc.nextLine();
                train.cancelTicket(name);
            }
            case 3 -> train.displayBookings();
            case 4 -> exitProgram();
            default -> System.out.println(" Invalid choice! Try again.");
        }
    }

    static void exitProgram() {
        System.out.println(" Exiting... Thank you for using the system!");
        System.exit(0);
    }
}



